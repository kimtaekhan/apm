#!/bin/sh

# clear print screen
clear

. /usr/local/src/apm/config/apm_config
. ${default_path}/ext/yum_install
. ${default_path}/ext/start_install
